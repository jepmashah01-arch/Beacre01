# Arusha Digital Studio — AI Client Assistant

A working full-stack starter built from the supplied Arusha Digital Studio HTML chatbot. Original premium dust-brown look, services, prices and portfolio disclaimers are preserved.

## Features
- Server-side OpenAI Responses API with bilingual (English / Swahili) agency-specific guidance.
- Conversation context limited to the latest 10 short exchanges; `store: false` requested from the provider.
- Guided FAQ fallback when an API key is not configured or temporarily unavailable.
- Service/package details and enquiry form with explicit consent.
- Optional SMTP enquiry delivery. If not configured, visitors can copy the enquiry or open a WhatsApp/email draft with studio-owned contact information.
- Helmet HTTP headers / Content Security Policy; server-only secrets; input validation, short requests and per-IP rate limits; anti-spam honeypot; no leads database or browser-persisted chat transcript.

## Local setup (Node.js 20+)
1. In a terminal, open this project folder.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and insert your OWN `OPENAI_API_KEY`. Choose an API model enabled for your account. **Never put the key in HTML or browser JavaScript.**
4. Optionally add `PUBLIC_WHATSAPP`, `PUBLIC_EMAIL`, and `PUBLIC_INSTAGRAM` (real, verified studio contacts only).
5. To accept on-site enquiry submissions, configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM`, and `ENQUIRY_TO`. Until configured the send button is disabled; copy/email/WhatsApp drafts remain available as configured.
6. Run `npm start`; open `http://localhost:3000`.

## Deploying
Deploy to a service that runs Node.js backend apps (not static-only hosting). Set all secrets in the host's environment dashboard, do **not** deploy `.env`. Require HTTPS in front of Node, configure a trusted proxy only if necessary, enable provider-side spending limits and alerting, and add domain-specific rate limits/CAPTCHA for a public site. For large multi-instance production deployments replace in-memory rate limiting with a shared store and add an anti-bot mechanism; add monitored email delivery and a retention/privacy policy before production launch.

## Privacy and limitations
- Chat messages are sent to the backend, then the configured OpenAI service when AI is active. Avoid sensitive data in chat.
- Direct enquiries send contact information to your configured email provider and destination address **only after explicit consent and button click**. No database is included.
- Copy / WhatsApp / email options generate drafts; the customer must send them.
- Portfolio content remains *concepts*, not invented past clients. Prices and packages follow the uploaded source and should be confirmed by the owner before launch.
- Server-side AI is not automatically active on download and requires an API key and billing. No live production deployment is claimed.
- Test with live credentials and SMTP before using with actual clients.
