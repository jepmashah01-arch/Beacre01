(()=>{'use strict';
const $=id=>document.getElementById(id);
const starters=['View services','Compare packages','Recommend a package','See portfolio concepts','Start an enquiry'];
const topics={
 services:'Our services include: social media content and management; graphic design; Reels and video editing; and tourism and hospitality marketing for local businesses, hotels, safari operators and restaurants.',
 packages:'INTRODUCTORY MONTHLY PACKAGES\n\nSTARTER · TZS 150,000/month\n8 graphics + 8 captions, monthly content plan, one revision per graphic.\n\nGROWTH · TZS 300,000/month\n12 graphics + 12 captions, 2 short Reels from client footage, monthly calendar and basic performance summary, up to two revision rounds.\n\nPREMIUM CONTENT · TZS 500,000/month\n16 graphics + 16 captions, 4 short Reels from client footage, campaign plan, content scheduling on up to two platforms, monthly performance report and up to two revision rounds.\n\nAd spend, photography, travel, software and third-party costs are excluded unless agreed separately. Final scope is confirmed in writing.',
 portfolio:'Illustrative portfolio CONCEPTS (not completed client commissions):\n\n• Safari Lodge — Experience the Beauty of Tanzania: poster and booking-focused caption.\n• Restaurant — More Than a Meal. An Experience: food graphic and Story.\n• Safari Operator — Your Next Adventure Begins in Tanzania: safari poster and Reel concept.',
 recommend:'Starter is best for a consistent foundation; Growth adds Reels and reporting; Premium adds more content, scheduling and campaign planning. Share your approximate monthly budget and business type for a closer recommendation.',
 about:'Arusha Digital Studio is an emerging creative marketing and content studio based in Arusha, Tanzania. Create. Connect. Grow.'
};
let config={aiEnabled:false,enquiriesEnabled:false,whatsapp:'',email:'',instagram:''};let history=[];let busy=false;
const msgs=$('messages'),input=$('chatInput');
function add(role,text){const el=document.createElement('div');el.className='message '+role;el.textContent=text;msgs.appendChild(el);msgs.scrollTop=msgs.scrollHeight;}
function quick(items=starters){const el=$('quick');el.replaceChildren();for(const t of items){const b=document.createElement('button');b.type='button';b.textContent=t;b.addEventListener('click',()=>respond(t));el.appendChild(b);}}
function open(id){$(id).classList.add('open');}function close(id){$(id).classList.remove('open');}
function guide(s){const v=s.toLowerCase();if(/(start an enquiry|contact|quote|hire|whatsapp|email|booking)/.test(v))return 'Use Start an enquiry to share your project details. We only send your enquiry after you approve it.';
if(/(package|price|cost|rate|bei|gharama|150,?000|300,?000|500,?000)/.test(v))return topics.packages;
if(/(portfolio|sample|example|concept)/.test(v))return topics.portfolio;
if(/(recommend|suggest|budget|afford)/.test(v))return topics.recommend;
if(/(services|offer|social|graphics|video|reels|tourism|hotel|lodge|safari|restaurant)/.test(v))return topics.services;
if(/(about|where|arusha|location)/.test(v))return topics.about;
if(/^(hi|hello|habari|mambo|jambo)/.test(v))return 'Karibu! I can explain our services, packages and help you prepare a project enquiry.';
return 'I can explain studio services, show introductory prices and prepare an enquiry. For a custom project, select Start an enquiry.';}
async function respond(s){s=s.trim();if(!s||busy)return;if(s.toLowerCase()==='start an enquiry'){add('user',s);add('bot','Tell us about your project using the form. Your details are only sent after you consent and select Send securely.');open('leadOverlay');return;}
add('user',s);input.value='';quick(['Start an enquiry','Compare packages','View services']);if(!config.aiEnabled){add('bot',guide(s)+'\n\n(Guided mode: live AI is not configured.)');return;}
const prior=history.slice(-10);busy=true;input.disabled=true;const send=$('chatForm').querySelector('button');send.disabled=true;const pending=document.createElement('div');pending.className='message bot';pending.textContent='Thinking…';msgs.appendChild(pending);msgs.scrollTop=msgs.scrollHeight;
try{const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:s.slice(0,800),history:prior})});const d=await r.json();pending.textContent=r.ok&&d.answer?d.answer:(d.error||guide(s));if(!r.ok)pending.textContent+='\n\n'+guide(s);history.push({role:'user',content:s.slice(0,800)},{role:'assistant',content:pending.textContent.slice(0,800)});history=history.slice(-10);}catch{pending.textContent='Connection unavailable. '+guide(s);}finally{busy=false;input.disabled=false;send.disabled=false;input.focus();msgs.scrollTop=msgs.scrollHeight;}}
$('chatForm').addEventListener('submit',e=>{e.preventDefault();respond(input.value)});
$('reset').addEventListener('click',()=>{history=[];msgs.replaceChildren();add('bot','Welcome back! How can we help your business?');quick()});
$('openLead').addEventListener('click',()=>open('leadOverlay'));
$('closeLead').addEventListener('click',()=>close('leadOverlay'));
for(const id of ['leadOverlay'])$(id).addEventListener('click',e=>{if(e.target===$(id))close(id)});
document.addEventListener('keydown',e=>{if(e.key==='Escape')close('leadOverlay')});
function data(){const f=$('leadForm');if(!f.reportValidity())return null;const x=Object.fromEntries(new FormData(f).entries());if(!x.phone.trim()&&!x.email.trim()){status('Please provide a phone number or email address.');return null;}x.consent=!!x.consent;return x;}
function message(x){return `Hello Arusha Digital Studio, I would like to enquire about your services.\n\nName: ${x.name}\nBusiness: ${x.business||'Not provided'}\nPhone: ${x.phone||'Not provided'}\nEmail: ${x.email||'Not provided'}\nService / package: ${x.service}\nProject details: ${x.details}\n\nPlease advise on scope and next steps.`;}
function status(s){$('leadStatus').textContent=s;}
$('copyLead').addEventListener('click',async()=>{const x=data();if(!x)return;try{await navigator.clipboard.writeText(message(x));status('Enquiry copied. Paste into your preferred messaging app.')}catch{status('Clipboard access was denied. Try WhatsApp or email.')}});
$('waLead').addEventListener('click',()=>{const x=data();if(!x)return;if(!config.whatsapp)return status('The studio WhatsApp contact has not been configured.');window.open('https://wa.me/'+config.whatsapp+'?text='+encodeURIComponent(message(x)),'_blank','noopener,noreferrer');status('WhatsApp opened. Please review and send the message there.');});
$('emailLead').addEventListener('click',()=>{const x=data();if(!x)return;if(!config.email)return status('The studio email address has not been configured.');location.href='mailto:'+encodeURIComponent(config.email)+'?subject='+encodeURIComponent('Project enquiry — Arusha Digital Studio')+'&body='+encodeURIComponent(message(x));status('Your email application may open a draft; review and send there.');});
$('sendLead').addEventListener('click',async()=>{const x=data();if(!x)return;if(!config.enquiriesEnabled)return status('Secure online sending is not yet configured. Use copy, email or WhatsApp instead.');const btn=$('sendLead');btn.disabled=true;status('Sending your enquiry…');try{const r=await fetch('/api/enquiry',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(x)});const result=await r.json();if(!r.ok)throw Error(result.error||'Could not send.');status('Enquiry successfully submitted to the studio.');$('leadForm').reset();}catch(e){status(e.message||'Send failed. Please try another contact option.')}finally{btn.disabled=false;}});
add('bot','Karibu! 👋 Welcome to Arusha Digital Studio.\n\nAsk about social media management, design, Reels, tourism marketing or monthly packages. I can also help you prepare a project enquiry.');quick();
fetch('/api/config').then(r=>r.ok?r.json():Promise.reject()).then(c=>{config={...config,...c};$('sendLead').disabled=!config.enquiriesEnabled;$('sendLead').title=config.enquiriesEnabled?'Send your enquiry to the studio':'Requires email delivery configuration';}).catch(()=>{add('bot','This is a preview. Connect the backend server to enable live AI and secure enquiry delivery.');$('sendLead').disabled=true;});
})();
